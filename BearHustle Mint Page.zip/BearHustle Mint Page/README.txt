1. Netlify / Vercel / GitHub Pages hesabı aç.
2. BearHustleMint folderini upload et.
3. Deploy düyməsini bas → URL hazır olur.
4. Mobil browser ilə aç, Connect Wallet → Mint NFT.
5. Domain almağa ehtiyac yoxdur. Linki istədiyin kimi paylaşa bilərsən.
