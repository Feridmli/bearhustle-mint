// Ethers.js provider və signer
let provider;
let signer;
let userAddress;

// Kontrakt məlumatları
const CONTRACT_ADDRESS = "SENIN_KONTRAKT_ADRESIN"; // buraya kontrakt adresini yaz
const ABI = [
  "function mint(uint256 quantity) external payable",
  "function maxPerWallet() view returns (uint256)",
  "function balanceOf(address owner) view returns (uint256)",
  "function totalSupply() view returns (uint256)",
  "function MAX_SUPPLY() view returns (uint256)",
  "function mintPrice() view returns (uint256)"
];

// HTML elementləri
const connectBtn = document.getElementById("connectBtn");
const mintBtn = document.getElementById("mintBtn");
const statusEl = document.getElementById("status");
const totalSupplyEl = document.getElementById("totalSupply");

// ---------------- Wallet Connect ----------------
connectBtn.addEventListener("click", async () => {
  if (typeof window.ethereum !== "undefined") {
    try {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      provider = new ethers.providers.Web3Provider(window.ethereum);
      signer = provider.getSigner();
      userAddress = await signer.getAddress();
      statusEl.textContent = `Connected: ${userAddress.substring(0,6)}...${userAddress.slice(-4)}`;
      await updateTotalSupply();
    } catch (err) {
      console.error(err);
      statusEl.textContent = "Connection failed";
    }
  } else {
    alert("Please install MetaMask!");
  }
});

// ---------------- Mint Max Available ----------------
mintBtn.addEventListener("click", async () => {
  if (!signer) {
    alert("Connect your wallet first!");
    return;
  }

  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);

  try {
    // Kontrakt məlumatlarını bir yerdə soruş
    const [maxPerWallet, userBalance, totalSupply, maxSupply, mintPrice] = await Promise.all([
      contract.maxPerWallet(),
      contract.balanceOf(userAddress),
      contract.totalSupply(),
      contract.MAX_SUPPLY(),
      contract.mintPrice()
    ]);

    // Mint edilə biləcək maksimum say
    const availableToMint = Math.min(maxPerWallet - userBalance, maxSupply - totalSupply);

    if (availableToMint <= 0) {
      statusEl.textContent = "You cannot mint more NFTs";
      return;
    }

    statusEl.textContent = `Minting ${availableToMint} NFT(s)...`;
    mintBtn.disabled = true;

    // Mint funksiyasını çağır
    const tx = await contract.mint(availableToMint, { value: mintPrice.mul(availableToMint) });
    await tx.wait();

    statusEl.textContent = `Successfully minted ${availableToMint} NFT(s)!`;
    mintBtn.disabled = false;

    // Total supply yenilə
    await updateTotalSupply();

  } catch (err) {
    console.error(err);
    statusEl.textContent = "Mint failed. See console.";
    mintBtn.disabled = false;
  }
});

// ---------------- Total Supply Update ----------------
async function updateTotalSupply() {
  if (!provider) return;
  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
  try {
    const [totalSupply, maxSupply] = await Promise.all([
      contract.totalSupply(),
      contract.MAX_SUPPLY()
    ]);
    totalSupplyEl.textContent = `${totalSupply} / ${maxSupply} minted`;
  } catch(err){
    console.error(err);
    totalSupplyEl.textContent = "Error fetching supply";
  }
}